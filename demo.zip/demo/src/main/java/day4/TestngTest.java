package day4;

import org.testng.annotations.Test;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class TestngTest {

	@Test(dependsOnMethods = "SecondTestNG")
	public void FirstTestNG(){
		System.out.println("First Test");
		
	}
	
	@Parameters({"browser","URL"})
	@Test
	public void SecondTestNG(String br, String url){
		System.out.println("Second Test");
		System.out.println("Browser= " + br);
		System.out.println("URL= " + url);
		
	}
	
	@Test(priority = 1)
	public void ThirdTestNG(){
		System.out.println("Third Test");
		
	}
}
