package stepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class GoogleSearch {
	
	WebDriver wd;
	
	@Given("I want to launch google.com")
	public void i_want_to_launch_google_com() throws Exception {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\0023WX744\\Documents\\Training\\demo\\chromedriver.exe");
		wd = new ChromeDriver();
		wd.get("https://www.google.com/");
		wd.manage().window().maximize();
		Thread.sleep(3000);
	}

	@When("I enter text {string}")
	public void i_enter_text(String string) {
		wd.findElement(By.name("q")).sendKeys(string+Keys.ENTER);
		}

}
