package day1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class DropDownTest {

	public static void main(String[] args) throws Exception {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\0023WX744\\Documents\\Training\\demo\\chromedriver.exe");
		WebDriver wd;
		wd = new ChromeDriver();
		wd.get("https://www.globalsqa.com/demo-site/select-dropdown-menu/");
		wd.manage().window().maximize();
		Thread.sleep(3000);
	    WebElement testDropDown = wd.findElement(By.tagName("select"));
	    System.out.println(testDropDown.isSelected());
	    System.out.println(testDropDown.isDisplayed());
	    Select slt = new Select(testDropDown);
	    slt.selectByValue("IND");
	    Thread.sleep(5000);
		wd.close();

	}

}
