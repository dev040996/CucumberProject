package day1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class SeleniumLaunch {

	public static void main(String[] args) throws Exception {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\0023WX744\\Documents\\Training\\demo\\chromedriver.exe");
		WebDriver wd;
		wd = new ChromeDriver();
		wd.get("https://www.google.com/");
		wd.manage().window().maximize();
		Thread.sleep(3000);
		System.out.println("URL:" + wd.getCurrentUrl());
		System.out.println("TITLE:" + wd.getTitle());
		
		wd.findElement(By.name("q")).sendKeys("Selenium is Good"+Keys.ENTER);
		Thread.sleep(3000);
		
		List<WebElement> listLinks = wd.findElements(By.xpath("//a/h3"));
//		for(int i=0; i<listLinks.size(); i++) {
//			System.out.println(listLinks.get(i).getText()); 
//			//listLinks.get(i).getAttribute("class");
//		}
		for(WebElement element:listLinks) {
			System.out.println(element.getText());
		}
		wd.close();

	}

}
