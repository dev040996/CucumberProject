package day1;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class AlertExample {

	public static void main(String[] args) throws Exception {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\0023WX744\\Documents\\Training\\demo\\chromedriver.exe");
		WebDriver wd;
		wd = new ChromeDriver();
		wd.get("http://demo.automationtesting.in/Alerts.html");
		wd.manage().window().maximize();
		wd.findElement(By.cssSelector(".btn.btn-danger")).click();
		wd.switchTo().alert().accept();
		Thread.sleep(3000);
		wd.findElement(By.xpath("//a[contains(text(),'Alert with OK & Cancel')]")).click();
		wd.findElement(By.xpath("//button[contains(text(),'click the button to display a confirm box')]")).click();
		wd.switchTo().alert().dismiss();
		System.out.println(wd.findElement(By.xpath("//p[@id='demo']")).getText());
		wd.findElement(By.xpath("//a[contains(text(),'Alert with Textbox')]")).click();
		wd.findElement(By.xpath("//button[contains(text(),'click the button to demonstrate the prompt box')]")).click();
		wd.switchTo().alert().sendKeys("Hi");
		wd.switchTo().alert().accept();
		System.out.println(wd.findElement(By.xpath("//p[@id='demo1']")).getText());
		
		
		


	}

}
