package day1;

import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class WebTableTest {

	public static void main(String[] args) throws Exception {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\0023WX744\\Documents\\Training\\demo\\chromedriver.exe");
		WebDriver wd;
		wd = new ChromeDriver();
		//wd.get("https://www.techlistic.com/p/demo-selenium-practice.html");
		wd.get("https://www.google.com/");
		wd.manage().window().maximize();
		//List<WebElement> table = wd.findElements(By.xpath("//table[@id='customers']//tr//td"));
		//for(WebElement data:table) {
			//System.out.println(data.getText());
		//}
		//List<WebElement> table = wd.findElements(By.xpath("//table[@id='customers']//tr//td[2]"));
		//for(WebElement data:table) {
		//	System.out.println(data.getText());
		//}
		//wd.findElement(By.xpath("//body")).sendKeys(Keys.CONTROL + "t");
		((JavascriptExecutor)wd).executeScript("window.open()");
		Set<String> wdw = wd.getWindowHandles();
		for(String s:wdw) {
			System.out.println(wdw);
			wd.switchTo().window(s);
		}
		Thread.sleep(3000);
		wd.close();

	}

}
