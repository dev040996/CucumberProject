package day1;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class ActionTest {

	public static void main(String[] args) throws Exception {
		// https://www.globalsqa.com/demo-site/frames-and-windows/#iFrame
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\0023WX744\\Documents\\Training\\demo\\chromedriver.exe");
		WebDriver wd;
		wd = new ChromeDriver();
		wd.get("https://www.google.com/");
		wd.manage().window().maximize();
		WebElement we = wd.findElement(By.name("q"));
		Actions action = new Actions(wd);
		action.keyDown(we,Keys.SHIFT);
		action.sendKeys("selenium");
		action.keyUp(we,Keys.SHIFT);
		action.build().perform();
		action.doubleClick(we);
		action.sendKeys(Keys.CONTROL + "C");
		Thread.sleep(3000);

	}

}
